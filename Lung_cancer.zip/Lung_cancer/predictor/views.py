from django.shortcuts import render
import joblib
import numpy as np

# Load trained model
model = joblib.load('model.pkl')


# Home page
def home(request):
    return render(request, 'index.html')


# Prediction page logic
def predict(request):
    if request.method == 'POST':

        age = int(request.POST['age'])
        smoking = int(request.POST['smoking'])
        coughing = int(request.POST['coughing'])

        data = np.array([[age, smoking, coughing]])

        result = model.predict(data)

        if result[0] == 1:
            answer = "⚠️ High Risk of Lung Cancer Detected. Please consult a doctor."
        else:
            answer = "✅ Low Risk of Lung Cancer. Stay healthy."

        return render(request, 'result.html', {'result': answer})

    return render(request, 'index.html')


# Login page
def login(request):
    return render(request, 'login.html')


# Report page
def report(request):
    return render(request, 'report.html')